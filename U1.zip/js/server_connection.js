"use strict"

async function fetch_resource(request) {

    const response = await fetch(request);
    return response;

}